import java.util.List;

public interface DuplicateCheck {

	public List<Integer> findDuplicates(List<Integer> integers);
}
