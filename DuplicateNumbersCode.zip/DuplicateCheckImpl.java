import static java.lang.Integer.parseInt;

import java.util.ArrayList;
import java.util.List;


public class DuplicateCheckImpl implements DuplicateCheck {

	
	/** 
	 * Returns a list containing numbers that have the all same digits based on the integers passed in the parameter.
	 * 
	 * @param integers, a list of integers
	 */
	@Override
	public List<Integer> findDuplicates(List<Integer> integers) {
		List<Integer> duplicates = new ArrayList<Integer>();
		
		if (isNullOrEmpty(integers)) { return duplicates; }
				
		for (Integer value : integers)
		{
			String valueAsString = value.toString();
			if (isOneDigit(valueAsString)) { continue; }
			if (areAllValuesTheSame(valueAsString, valueAsString.charAt(0))) { duplicates.add(parseInt(valueAsString)); }
		}
		return duplicates;
	}

	private boolean isOneDigit(String temp) {
		return temp.length() == 1;
	}

	private boolean isNullOrEmpty(List<Integer> integers) {
		if (integers == null) { return true; }
		if (integers.isEmpty()) { return true; }
		return false;
	}

	private boolean areAllValuesTheSame(String temp, Character firstPosition) {

		for (Character theChar : temp.toCharArray()) {
			if (!theChar.equals(firstPosition)) { return false; }
		}
		return true;
	}

}
