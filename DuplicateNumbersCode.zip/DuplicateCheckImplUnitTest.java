import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;



public class DuplicateCheckImplUnitTest {
	
	private static final List<Integer> SINGLE_DIGIT_LIST = buildList(1);
	private static final List<Integer> EMPTY_LIST = new ArrayList<Integer>();
	private static final List<Integer> NULL_LIST = null;
	private static final List<Integer> RETURNS_ONE_NUMBERS = buildList(1, 11);
	private static final List<Integer> RETURNS_TWO_NUMBERS = buildList(1, 11, 21, 112, 222);
	private static final List<Integer> RETURNS_FIVE_NUMBERS = buildList(11, 777, 888, 55, 9999);
	private static final List<Integer> RETURNS_NO_NUMBERS = buildList(6, 96, 18, 15);
	
	private DuplicateCheckImpl impl = new DuplicateCheckImpl();

	public void setUp() {
		
	}
	
	@Test
	public void validateNullReturnsWhenNullPassedIn() {
		assertEquals(true, impl.findDuplicates(NULL_LIST).isEmpty());
	}
	
	@Test
	public void validateEmptyListReturnsWhenEmptyListPassedIn() {
		assertEquals(true, impl.findDuplicates(EMPTY_LIST).isEmpty());
	}

	@Test
	public void validateEmptyListReturnsWhenOnlySingleDigitPassedIn() {
		assertEquals(true, impl.findDuplicates(SINGLE_DIGIT_LIST).isEmpty());
	}
	
	@Test
	public void validateOneDuplicateElementReturnsInListWhenGivenTwoElements() {
		assertEquals(1, impl.findDuplicates(RETURNS_ONE_NUMBERS).size());
	}
	
	@Test
	public void validateTwoDuplicateElementsReturnWhenGivenFiveElements() {
		assertEquals(true, impl.findDuplicates(RETURNS_TWO_NUMBERS).containsAll(buildList(11,222)));
		assertEquals(2, impl.findDuplicates(RETURNS_TWO_NUMBERS).size());
	}
	
	@Test
	public void validateAllDuplicatesElementsReturnWhenGiveFiveElements() {
		assertEquals(true, impl.findDuplicates(RETURNS_FIVE_NUMBERS).containsAll(buildList(11, 777, 888, 55, 9999)));
		assertEquals(5, impl.findDuplicates(RETURNS_FIVE_NUMBERS).size());
	}
			
	@Test
	public void validateNoDuplicateElementsReturnWhenGivenListWithNoDuplicates() {
		assertEquals(0, impl.findDuplicates(RETURNS_NO_NUMBERS).size());
	}
	
	private static List<Integer> buildList(Integer... integerArray) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (Integer ints : integerArray) {
			list.add(ints);
		}
		return list; 
	}
}
